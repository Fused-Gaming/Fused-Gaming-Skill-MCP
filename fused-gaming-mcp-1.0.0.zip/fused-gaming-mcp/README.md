# Fused Gaming Skills MCP Server

**Model Context Protocol (MCP) server** that exposes all Fused Gaming custom skills as callable tools in Claude.

## What This Is

An MCP server that brings 7 custom skills to Claude as tools:

- **algorithmic-art** — Generate p5.js generative art with seeded randomness
- **ascii-mockup** — Create responsive UI wireframes (5 breakpoints, design tokens)
- **frontend-design** — Build production-grade frontend interfaces
- **mermaid-terminal** — Create flowcharts, sequences, state machines, etc.
- **project-status-tool** — Generate unified project status dashboards
- **ux-journey-mapper** — Map user journeys with pain points & opportunities
- **pre-deploy-validator** — Run pre-deployment validation checks

## Installation

### Prerequisites
- Node.js ≥ 18
- npm ≥ 9

### Setup

```bash
# Clone or download this repo
git clone https://github.com/fused-gaming/mcp-server.git
cd fused-gaming-mcp

# Install dependencies
npm install

# Build TypeScript
npm run build
```

### Connect to Claude.ai

1. **Get the server URL** (if self-hosted):
   ```bash
   npm run dev
   # Server runs at: stdio (standard input/output)
   ```

2. **In Claude.ai**, go to **Settings → Connected tools**

3. **Add MCP Server**:
   - **Type**: Model Context Protocol
   - **Name**: `fused-gaming-skills`
   - **URL**: `http://localhost:3000` (or your deployment URL)
   - **Auth**: None required

4. **Reload Claude** — tools now available

## Usage

Once connected, in Claude you can:

### List all skills
```
Use the list-skills tool to see all available Fused Gaming skills.
```

### Get skill documentation
```
Use the get-skill tool with skill="algorithmic-art" to see full documentation.
```

### Create algorithmic art
```
Use the create-algorithmic-philosophy tool to generate an art philosophy,
then generate-p5-sketch to implement it.
```

### Design a UI
```
Use the create-ascii-mockup tool to generate wireframes across all breakpoints.
Then use generate-tokens for design tokens (JSON + CSS).
```

### Create diagrams
```
Use the create-diagram tool with type="flowchart" to generate Mermaid diagrams.
```

### Map user journeys
```
Use the create-journey-map tool with a persona to generate a UX journey map.
```

### Pre-deployment validation
```
Use the run-validation tool to check code quality, security, tests, dependencies, docs.
```

## Architecture

```
fused-gaming-mcp/
├── src/
│   └── index.ts          ← MCP server (defines tools, handles requests)
├── skills/               ← Copy your SKILL.md files here
│   ├── algorithmic-art/
│   ├── ascii-mockup/
│   ├── frontend-design/
│   ├── mermaid-terminal/
│   ├── project-status-tool/
│   ├── ux-journey-mapper/
│   └── pre-deploy-validator/
├── dist/                 ← Compiled JavaScript (generated)
├── package.json
├── tsconfig.json
└── README.md
```

## Available Tools

### Skill Management
- `list-skills` — List all available skills
- `get-skill` — Get full documentation for a skill
- `get-skill-details` — Get metadata (name, description, tools, category)

### Creative
- `create-algorithmic-philosophy` — Generate art philosophy
- `generate-p5-sketch` — Implement p5.js sketch
- `design-component` — Design a frontend component

### Design
- `create-ascii-mockup` — Generate ASCII wireframes (5 breakpoints)
- `generate-tokens` — Create design tokens (JSON + CSS)
- `create-diagram` — Create Mermaid diagrams

### Project Management
- `view-status` — Get project status dashboard
- `create-journey-map` — Map user journeys
- `run-validation` — Pre-deployment validation

## Configuration

### Add Your Skills

Copy your skill files into the `skills/` directory:

```bash
cp -r /path/to/your/skills/algorithmic-art ./skills/
cp -r /path/to/your/skills/ascii-mockup ./skills/
# ... etc
```

Then update `src/index.ts` to reference them:

```typescript
const SKILLS: Skill[] = [
  {
    name: "algorithmic-art",
    description: "...",
    path: "skills/algorithmic-art/SKILL.md",
    category: "creative",
    tools: ["create-algorithmic-philosophy", "generate-p5-sketch", ...]
  },
  // ... more skills
];
```

### Customize Tool Handlers

Each tool has a handler in `handleToolCall()`:

```typescript
case "create-algorithmic-philosophy": {
  // Your custom logic here
  return `Philosophy framework...`;
}
```

Expand these to call actual implementations, APIs, or external services.

## Development

### Build
```bash
npm run build
```

### Watch mode
```bash
npm run dev
```

### Test
```bash
npm test
```

### Type check
```bash
npm run type-check
```

### Lint
```bash
npm run lint
```

## Deployment

### Option 1: Local (Development)
```bash
npm run dev
# Server accessible via stdio
```

### Option 2: Docker
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN npm install && npm run build
CMD ["node", "dist/index.js"]
```

### Option 3: Cloud (Vercel, Railway, Heroku)
```bash
# Add to package.json scripts
"start": "node dist/index.js"

# Deploy as normal web service
vercel deploy
# or
railway up
```

### Option 4: GitHub (Actions Workflow)
```yaml
name: Deploy MCP Server
on: [push]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: "20"
      - run: npm install && npm run build
      - run: npm test
      - uses: your-deployment-action@v1
```

## Extending the Server

### Add a New Skill

1. **Create SKILL.md** in `skills/your-skill/`
2. **Add to SKILLS array** in `src/index.ts`:
   ```typescript
   {
     name: "your-skill",
     description: "...",
     path: "skills/your-skill/SKILL.md",
     category: "category",
     tools: ["tool1", "tool2"]
   }
   ```
3. **Add tool handlers**:
   ```typescript
   case "tool1": {
     return "Result...";
   }
   ```
4. **Add tool definitions** in `ListToolsRequestSchema` handler
5. **Rebuild**: `npm run build`

### Connect External APIs

```typescript
case "create-diagram": {
  const { type, name } = input;
  // Call actual Mermaid API
  const result = await fetch("https://mermaid.api.example.com/create", {
    method: "POST",
    body: JSON.stringify({ type, name })
  });
  return await result.json();
}
```

## Troubleshooting

### "Tool not found"
- Ensure skill is in SKILLS array
- Check tool name matches handler case
- Rebuild: `npm run build`

### "SKILL.md not found"
- Verify skill files exist in `skills/` directory
- Check path in SKILLS definition
- Restart server

### Connection issues
- Check server is running: `npm run dev`
- Verify URL in Claude.ai settings
- Check firewall/network access
- Look at console errors

## Performance Tips

1. **Cache skill documentation** — read SKILL.md once on startup
2. **Lazy load** — only load skill content when requested
3. **Rate limit** — throttle API calls to external services
4. **Stream responses** — for large diagram/design outputs
5. **Batch operations** — process multiple items efficiently

## API Reference

### ListToolsRequestSchema
Returns array of available tools with descriptions and input schemas.

### CallToolRequestSchema
Calls a tool with name and arguments.

**Response**:
```json
{
  "content": [
    {
      "type": "text",
      "text": "Result from tool..."
    }
  ]
}
```

## Contributing

Issues & PRs welcome!

```bash
git checkout -b feature/my-skill
# Make changes
npm run build && npm test
git commit -m "Add my-skill"
git push
```

## License

MIT — See LICENSE.txt

## Support

- GitHub Issues: [fused-gaming/mcp-server/issues](https://github.com/fused-gaming/mcp-server)
- Discussions: [fused-gaming/mcp-server/discussions](https://github.com/fused-gaming/mcp-server)

---

**Created by**: Fused Gaming  
**Status**: v1.0.0 (Production Ready)
