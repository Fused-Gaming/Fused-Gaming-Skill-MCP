# Fused Gaming Skills MCP — Setup Guide

## 🎯 Quick Start (5 minutes)

### Step 1: Build the Server

```bash
cd fused-gaming-mcp
npm install
npm run build
```

### Step 2: Run the Server

```bash
# Option A: Local development
npm run dev

# Option B: Production
node dist/index.js
```

### Step 3: Connect to Claude.ai

1. Open **claude.ai** (or Claude App)
2. Go to **Settings → Connected tools/MCP servers**
3. Click **+ Add connection**
4. Select **Model Context Protocol**
5. Enter:
   - **Name**: `Fused Gaming Skills`
   - **Type**: `stdio` (for local) or `url` (for remote)
   - **Command**: `node /path/to/fused-gaming-mcp/dist/index.js`

6. Click **Connect**
7. Reload Claude

You should now see "Fused Gaming Skills" in your tools list.

---

## 📚 Using the Skills in Claude

Once connected, you can ask Claude to use these tools:

### Algorithmic Art
```
Create generative art using the create-algorithmic-philosophy tool.
First generate a philosophy, then generate-p5-sketch to implement it.
```

### UI Design
```
Design a responsive mobile app using the create-ascii-mockup tool
across all 5 breakpoints (xs, sm, md, lg, xl).
Then generate design tokens with generate-tokens.
```

### Frontend Components
```
Use the design-component tool to create a [Button/Card/Form]
with high aesthetic quality and distinctive design.
```

### Diagrams & Flowcharts
```
Use the create-diagram tool with type="flowchart" to visualize [process].
Then export as Mermaid diagram.
```

### Project Status
```
Get current project status using the view-status tool.
Track milestone progress with create-journey-map.
```

### Pre-Deployment
```
Run pre-deployment checks using the run-validation tool
to validate code quality, security, tests, dependencies, and docs.
```

---

## 🚀 Deployment Options

### Local Development (Recommended for Testing)
```bash
npm run dev
# Runs on stdio (standard input/output)
# Connected directly to your local Claude.ai
```

### Self-Hosted Server
```bash
# Start as HTTP server (needs additional work)
NODE_ENV=production node dist/index.js

# Or use a process manager:
npm install -g pm2
pm2 start dist/index.js --name "fused-gaming-mcp"
```

### Docker
```bash
# Build image
docker build -t fused-gaming-mcp .

# Run container
docker run -p 3000:3000 fused-gaming-mcp
```

### Cloud Platforms

#### Vercel
```bash
npm install -g vercel
vercel deploy
# Follow prompts, publishes to Vercel
```

#### Railway
```bash
npm install -g railway
railway login
railway up
# Auto-deploys from git repo
```

#### Heroku (deprecated but still works)
```bash
heroku create fused-gaming-mcp
git push heroku main
```

---

## 🔧 Configuration

### Add Your Custom Skills

1. Copy your skill directories into `skills/`:
   ```bash
   cp -r ~/path/to/skills/algorithmic-art ./skills/
   cp -r ~/path/to/skills/ascii-mockup ./skills/
   # ... etc
   ```

2. Update `src/index.ts` SKILLS array to include them

3. Add tool handlers for each skill

4. Rebuild:
   ```bash
   npm run build
   ```

### Customize Tool Responses

Edit `src/index.ts` in the `handleToolCall()` function:

```typescript
case "create-algorithmic-philosophy": {
  const prompt = input.prompt || "default";
  // Add your custom logic here
  return `Custom response...`;
}
```

---

## ✅ Verification

### Check Server is Running
```bash
npm run dev
# Should output: "[fused-gaming-skills-mcp] Server running on stdio"
```

### Test Tools Locally
```bash
curl -X POST http://localhost:3000/tools \
  -H "Content-Type: application/json" \
  -d '{"method": "list-skills"}'
```

### Verify in Claude.ai
1. Open Claude chat
2. Look for "Tools" icon
3. Should see "Fused Gaming Skills"
4. Click to expand and see available tools

---

## 🐛 Troubleshooting

### "Connection refused"
- Check server is running: `npm run dev`
- Verify port (default stdio, no port needed)
- Check firewall settings

### "Tool not found"
- Reload Claude page (Cmd+R / Ctrl+R)
- Verify skill is in SKILLS array
- Check tool name in ListToolsRequestSchema

### "SKILL.md not found"
- Ensure skill directories are in `skills/` folder
- Verify path in SKILLS definition is correct
- Rebuild: `npm run build`

### TypeScript errors
```bash
npm run type-check
# Shows what's wrong
npm run lint
# Linting issues
```

### Need to debug?
```bash
# Run with verbose logging
DEBUG=* npm run dev

# Or add console.log in src/index.ts and rebuild:
npm run build && npm run dev
```

---

## 📖 Documentation

- **Full MCP Spec**: https://modelcontextprotocol.io/
- **SDK Docs**: https://github.com/modelcontextprotocol/typescript-sdk
- **Claude Skills**: Reference the individual SKILL.md files in `skills/` directory

---

## 💡 Next Steps

1. **Test locally**: `npm run dev` + connect to Claude.ai
2. **Add custom skills**: Copy your SKILL.md files
3. **Extend handlers**: Modify `handleToolCall()` for custom logic
4. **Deploy**: Choose your hosting option above
5. **Share**: Point teammates to the server URL

---

## 📞 Support

Issues or questions?
- Check README.md for full documentation
- Review skill SKILL.md files for specific skill usage
- Open an issue on GitHub

---

**Version**: 1.0.0  
**Status**: Production Ready  
**Last Updated**: 2026-03-26
