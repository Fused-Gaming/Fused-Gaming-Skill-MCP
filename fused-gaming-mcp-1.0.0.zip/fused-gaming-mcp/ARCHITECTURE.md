# Fused Gaming Skills MCP — Architecture

## Overview

The **Fused Gaming Skills MCP** is a Model Context Protocol server that exposes custom skills as callable tools in Claude.

```
┌─────────────────────────────────────────────────────────────┐
│                      Claude.ai / Claude App                  │
│                                                              │
│  User: "Create algorithmic art"                             │
│         ↓                                                    │
│  Claude calls: create-algorithmic-philosophy tool           │
│         ↓                                                    │
└─────────────────────────────────────────────────────────────┘
           │
           │ (MCP Protocol - stdio or HTTP)
           │
┌─────────────────────────────────────────────────────────────┐
│       Fused Gaming Skills MCP Server (Node.js)               │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  ListToolsRequestSchema Handler                      │   │
│  │  - Returns all available tools & descriptions        │   │
│  └─────────────────────────────────────────────────────┘   │
│           ↓                                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  CallToolRequestSchema Handler                      │   │
│  │  - Routes to handleToolCall(name, input)            │   │
│  └─────────────────────────────────────────────────────┘   │
│           ↓                                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Tool Handlers (switch statement)                   │   │
│  │  - create-algorithmic-philosophy                    │   │
│  │  - generate-p5-sketch                               │   │
│  │  - create-ascii-mockup                              │   │
│  │  - generate-tokens                                  │   │
│  │  - design-component                                 │   │
│  │  - create-diagram                                   │   │
│  │  - view-status                                      │   │
│  │  - create-journey-map                               │   │
│  │  - run-validation                                   │   │
│  │  ... (more tools)                                   │   │
│  └─────────────────────────────────────────────────────┘   │
│           ↓                                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Skill Files (skills/ directory)                    │   │
│  │  - algorithmic-art/SKILL.md                         │   │
│  │  - ascii-mockup/SKILL.md                            │   │
│  │  - frontend-design/SKILL.md                         │   │
│  │  - mermaid-terminal/SKILL.md                        │   │
│  │  - project-status-tool/SKILL.md                     │   │
│  │  - ux-journey-mapper/SKILL.md                       │   │
│  │  - pre-deploy-validator/SKILL.md                    │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
           ↑
           │ (MCP Response)
           │
┌─────────────────────────────────────────────────────────────┐
│  Claude: "Here's your algorithmic philosophy..."            │
│  Claude: "Now let me generate the p5.js code..."            │
└─────────────────────────────────────────────────────────────┘
```

## Key Components

### 1. Server (`src/index.ts`)
- **Framework**: @modelcontextprotocol/sdk
- **Transport**: stdio (standard input/output)
- **Request Handlers**:
  - `ListToolsRequestSchema` — Returns available tools
  - `CallToolRequestSchema` — Executes tool calls

### 2. Skills Array
Defines all available skills with metadata:
```typescript
interface Skill {
  name: string;           // "algorithmic-art"
  description: string;    // "Create generative art..."
  path: string;          // "skills/algorithmic-art/SKILL.md"
  category: string;      // "creative", "design", etc.
  tools: string[];       // ["create-algorithmic-philosophy", ...]
}
```

### 3. Tool Handlers
Each tool has a case in `handleToolCall()`:
```typescript
case "create-algorithmic-philosophy": {
  const prompt = input.prompt || "default";
  // Generate and return response
  return `Philosophy framework...`;
}
```

### 4. Skill Files
Reference SKILL.md files stored in `skills/` directory.
These provide detailed guidance for each skill's implementation.

## Data Flow

### Request Flow
```
1. User in Claude: "Create algorithmic art"
2. Claude detects relevant tool
3. Claude calls: CallToolRequest
   {
     name: "create-algorithmic-philosophy",
     arguments: {
       prompt: "organic emergence pattern"
     }
   }
4. MCP Server receives request
5. Routes to handleToolCall("create-algorithmic-philosophy", {...})
6. Handler returns response
7. Claude receives response
8. Claude presents to user
```

### Response Structure
```json
{
  "content": [
    {
      "type": "text",
      "text": "Generated response text"
    }
  ],
  "isError": false
}
```

## Tool Categories

### Skill Management (3 tools)
- `list-skills` — List all available skills
- `get-skill` — Get full SKILL.md documentation
- `get-skill-details` — Get metadata

### Creative (3 tools)
- `create-algorithmic-philosophy` — Art philosophy
- `generate-p5-sketch` — p5.js implementation
- `design-component` — Frontend component design

### Design (3 tools)
- `create-ascii-mockup` — UI wireframes (5 breakpoints)
- `generate-tokens` — Design tokens (JSON + CSS)
- `create-diagram` — Mermaid diagrams

### Project Management (3 tools)
- `view-status` — Project status dashboard
- `create-journey-map` — UX journey maps
- `run-validation` — Pre-deployment validation

## Implementation Details

### Technology Stack
- **Language**: TypeScript 5.0
- **Runtime**: Node.js ≥ 18
- **MCP SDK**: @modelcontextprotocol/sdk v1.0
- **Build Tool**: tsc (TypeScript compiler)
- **Testing**: Jest
- **Linting**: ESLint + TypeScript

### Compilation
```bash
npm run build
# src/index.ts (TS) → dist/index.js (JS)
```

### Startup
```bash
npm run dev
# Runs compiled server on stdio
```

## Extensibility

### Adding New Skills

1. **Create skill files** in `skills/your-skill/`
2. **Add to SKILLS array**:
   ```typescript
   {
     name: "your-skill",
     description: "...",
     path: "skills/your-skill/SKILL.md",
     category: "category",
     tools: ["tool1", "tool2"]
   }
   ```
3. **Add handlers** in `handleToolCall()`
4. **Add tool definitions** in ListToolsRequestSchema
5. **Rebuild**: `npm run build`

### Connecting to External APIs

```typescript
case "my-tool": {
  const result = await fetch("https://api.example.com/endpoint", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  });
  return await result.json();
}
```

### Adding Database Support

```typescript
import sqlite3 from "sqlite3";

const db = new sqlite3.Database(":memory:");

case "save-skill-data": {
  db.run(
    "INSERT INTO skills (name, data) VALUES (?, ?)",
    [input.name, JSON.stringify(input.data)],
    (err) => {
      if (err) throw err;
      return "Saved successfully";
    }
  );
}
```

## Performance Considerations

### Startup Time
- **Current**: ~500ms (just loads server)
- **With file I/O**: ~1-2s (reads all SKILL.md files on startup)
- **With DB**: ~2-3s (queries initial data)

### Request Latency
- **Tool listing**: ~50ms
- **Tool execution**: <100ms (most handlers are synchronous)
- **External API calls**: 500ms-5s (depends on service)

### Optimization Tips
1. **Cache SKILL.md files** on startup
2. **Lazy load** skill content only when requested
3. **Use Connection pooling** for database
4. **Rate limit** external API calls
5. **Stream large responses** instead of buffering

## Security

### Input Validation
Each tool should validate input before processing:
```typescript
case "create-diagram": {
  if (!input.type || typeof input.type !== "string") {
    throw new Error("Missing or invalid 'type' parameter");
  }
  // ... proceed
}
```

### Rate Limiting
Prevent abuse of external API calls:
```typescript
const limiter = new RateLimit({ max: 100, windowMs: 60000 });

case "create-diagram": {
  limiter.consume(1);
  // ... call external API
}
```

### Error Handling
Always catch and return errors gracefully:
```typescript
try {
  const result = await externalApi.call();
  return result;
} catch (error) {
  return {
    content: [{ type: "text", text: `Error: ${error.message}` }],
    isError: true
  };
}
```

## Testing Strategy

### Unit Tests
Test individual tool handlers:
```typescript
test("create-algorithmic-philosophy returns valid response", () => {
  const result = handleToolCall("create-algorithmic-philosophy", {
    prompt: "test"
  });
  expect(result).toContain("Algorithmic Philosophy");
});
```

### Integration Tests
Test full request/response cycle:
```typescript
test("MCP server responds to ListToolsRequest", async () => {
  const request = { method: "LIST_TOOLS" };
  const response = await server.handle(request);
  expect(response.tools.length).toBeGreaterThan(0);
});
```

### E2E Tests
Test Claude integration:
```typescript
test("Claude can call create-diagram tool", async () => {
  const tools = await claude.listTools();
  expect(tools).toContainEqual(
    expect.objectContaining({ name: "create-diagram" })
  );
});
```

## Deployment Checklist

- [ ] Run `npm run build` successfully
- [ ] Run `npm test` — all tests pass
- [ ] Run `npm run lint` — no errors
- [ ] Run `npm run type-check` — no type errors
- [ ] Test locally: `npm run dev`
- [ ] Connect to Claude.ai
- [ ] Test each tool manually
- [ ] Review error handling
- [ ] Document any custom configuration
- [ ] Set up monitoring/logging
- [ ] Deploy to production
- [ ] Verify on production instance

## Monitoring & Debugging

### Enable Debug Logging
```bash
DEBUG=* npm run dev
```

### Check Server Health
```bash
curl -X POST localhost:3000/health
# Should return { status: "ok" }
```

### View Logs
```bash
tail -f /var/log/fused-gaming-mcp.log
```

### Monitor Tool Usage
```bash
# Count tool calls per day
grep "CallToolRequest" logs.txt | wc -l

# Find slow tool calls
grep "duration.*>1000" logs.txt
```

## Future Enhancements

- [ ] Caching layer for skill documentation
- [ ] Database backend for storing skill data
- [ ] Web UI for skill management
- [ ] Webhook support for async operations
- [ ] Rate limiting and authentication
- [ ] Telemetry and analytics
- [ ] Plugin system for third-party skills
- [ ] Multi-language support
- [ ] Skill versioning and rollback
- [ ] A/B testing framework for skill improvements

---

**Version**: 1.0.0  
**Status**: Production Ready  
**Last Updated**: 2026-03-26
