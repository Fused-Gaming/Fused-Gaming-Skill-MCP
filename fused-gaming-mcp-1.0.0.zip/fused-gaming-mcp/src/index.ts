#!/usr/bin/env node

import {
  Server,
  StdioServerTransport,
} from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  TextContent,
  ToolUseBlock,
} from "@modelcontextprotocol/sdk/types.js";
import * as fs from "fs";
import * as path from "path";

// ═══════════════════════════════════════════════════════════════════════════
// FUSED GAMING SKILLS MCP SERVER
// ═══════════════════════════════════════════════════════════════════════════
// 
// Exposes custom Fused Gaming skills as MCP tools:
// - algorithmic-art: Generate p5.js generative art
// - ascii-mockup: Create responsive UI wireframes
// - frontend-design: Build production-grade interfaces
// - mermaid-terminal: Create diagrams and flowcharts
// - project-status-tool: Generate project status dashboards
// - ux-journey-mapper: Map user journeys
// - pre-deploy-validator: Validate pre-deployment checks
//

interface Skill {
  name: string;
  description: string;
  path: string;
  category: string;
  tools: string[];
}

// Initialize MCP server
const server = new Server({
  name: "fused-gaming-skills",
  version: "1.0.0",
});

// Define available skills
const SKILLS: Skill[] = [
  {
    name: "algorithmic-art",
    description:
      "Create generative art using p5.js with seeded randomness and algorithmic philosophy",
    path: "skills/algorithmic-art/SKILL.md",
    category: "creative",
    tools: [
      "create-algorithmic-philosophy",
      "generate-p5-sketch",
      "export-sketch",
    ],
  },
  {
    name: "ascii-mockup",
    description:
      "Generate responsive ASCII UI mockups across 5 breakpoints with design tokens",
    path: "skills/ascii-mockup/SKILL.md",
    category: "design",
    tools: [
      "create-ascii-mockup",
      "generate-tokens",
      "export-mockup",
      "check-wcag-compliance",
    ],
  },
  {
    name: "frontend-design",
    description:
      "Create distinctive, production-grade frontend interfaces with high design quality",
    path: "skills/frontend-design/SKILL.md",
    category: "design",
    tools: ["design-component", "build-landing-page", "create-dashboard"],
  },
  {
    name: "mermaid-terminal",
    description:
      "Generate, render, and export Mermaid diagrams (flowcharts, sequences, state machines)",
    path: "skills/mermaid-terminal/SKILL.md",
    category: "documentation",
    tools: [
      "create-diagram",
      "export-diagram",
      "batch-process-diagrams",
      "validate-diagram",
    ],
  },
  {
    name: "project-status-tool",
    description:
      "Unified project status dashboard integrating versions, branches, milestones, and metrics",
    path: "skills/project-status-tool/SKILL.md",
    category: "project-management",
    tools: [
      "view-status",
      "generate-report",
      "track-milestone",
      "compare-versions",
    ],
  },
  {
    name: "ux-journey-mapper",
    description:
      "Create detailed, versioned UX journey maps with multi-format export",
    path: "skills/ux-journey-mapper/SKILL.md",
    category: "design",
    tools: [
      "create-journey-map",
      "export-journey",
      "analyze-pain-points",
      "track-emotional-arc",
    ],
  },
  {
    name: "pre-deploy-validator",
    description:
      "Conduct comprehensive pre-deployment flight checks (code quality, security, tests, deps, docs)",
    path: "skills/pre-deploy-validator/SKILL.md",
    category: "devops",
    tools: [
      "run-validation",
      "check-code-quality",
      "scan-security",
      "validate-tests",
    ],
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// TOOL HANDLERS
// ═══════════════════════════════════════════════════════════════════════════

async function readSkillFile(skillName: string): Promise<string> {
  const skill = SKILLS.find((s) => s.name === skillName);
  if (!skill) {
    throw new Error(`Skill '${skillName}' not found`);
  }

  // In a real implementation, skills would be packaged with the MCP server
  // For now, return skill metadata and description
  return `# ${skill.name}

${skill.description}

**Category**: ${skill.category}

**Available Tools**:
${skill.tools.map((t) => `- ${t}`).join("\n")}

To use this skill, provide context and requirements. The skill will guide implementation.`;
}

interface ToolInput {
  skill?: string;
  action?: string;
  config?: Record<string, unknown>;
  prompt?: string;
  [key: string]: unknown;
}

async function handleToolCall(
  toolName: string,
  input: ToolInput
): Promise<string> {
  switch (toolName) {
    // Skill retrieval
    case "get-skill": {
      if (!input.skill) throw new Error("Missing 'skill' parameter");
      return await readSkillFile(input.skill as string);
    }

    case "list-skills": {
      return JSON.stringify(
        SKILLS.map((s) => ({
          name: s.name,
          description: s.description,
          category: s.category,
          tools: s.tools,
        })),
        null,
        2
      );
    }

    case "get-skill-details": {
      if (!input.skill) throw new Error("Missing 'skill' parameter");
      const skill = SKILLS.find((s) => s.name === input.skill);
      if (!skill) throw new Error(`Skill '${input.skill}' not found`);
      return JSON.stringify(skill, null, 2);
    }

    // Algorithmic Art
    case "create-algorithmic-philosophy": {
      const prompt = input.prompt || "Create an original algorithmic art philosophy";
      return `## Algorithmic Philosophy Framework

**Input**: ${prompt}

To create an algorithmic philosophy:

1. **Name the movement** (1-2 words)
2. **Articulate philosophy** (4-6 paragraphs):
   - Computational processes
   - Noise and randomness patterns
   - Particle behaviors
   - Temporal evolution
   - Parametric variation

3. **Emphasize craftsmanship** — mention that the algorithm should appear meticulously crafted, refined through countless iterations

4. **Leave creative space** for implementation choices

This philosophy will guide the p5.js implementation.`;
    }

    case "generate-p5-sketch": {
      const philosophy = input.philosophy || "organic emergence";
      return `## P5.js Implementation

Based on philosophy: "${philosophy}"

**Template structure**:
\`\`\`javascript
let params = {
  seed: 12345,
  // Add parameters from your philosophy
};

function setup() {
  createCanvas(1200, 1200);
  randomSeed(params.seed);
  noiseSeed(params.seed);
  initializeSystem();
}

function draw() {
  // Your generative algorithm here
}

class Entity {
  // Define entities from your philosophy
}
\`\`\`

Use the algorithmic-art skill SKILL.md for complete guidance.`;
    }

    // ASCII Mockup
    case "create-ascii-mockup": {
      const screens = input.screens || "mobile-first";
      return `## ASCII Mockup Generation

**Breakpoints** (mobile-first):
- xs: iPhone 720 (48 cols)
- sm: iPad (96 cols)
- md: Desktop 1440 (180 cols)
- lg: Desktop 1920 (240 cols)
- xl: UWHD 3440 (430 cols)

**Output for each**:
1. ASCII wireframe with component layout
2. Annotation block with token references
3. ARIA color compliance table
4. Component directory scaffold
5. CHANGELOG entry with SemVer bump

Use the ascii-mockup skill SKILL.md for complete process.`;
    }

    case "generate-tokens": {
      return `## Design Token Generation

**tokens.json schema**:
- color (brand, semantic, neutral scale)
- typography (fonts, scale, weight, leading)
- spacing (0 → 32)
- radius, shadow, z-index, motion

**tokens.css output**:
- CSS custom properties (--color-*, --space-*, etc.)
- Google Fonts @import
- Dark mode overrides
- Reduced motion support

All values zero-hardcoded — CSS variables only.`;
    }

    // Frontend Design
    case "design-component": {
      const component = input.component || "Button";
      return `## Frontend Component Design

**${component}**

Design thinking:
1. **Purpose**: What problem does it solve?
2. **Tone**: Pick an aesthetic direction (minimalist, maximalist, brutalist, etc.)
3. **Constraints**: Technical requirements
4. **Differentiation**: What makes it memorable?

Then implement with:
- Distinctive typography
- Cohesive color palette
- Thoughtful motion/animation
- Spatial composition
- Background effects/textures

Use the frontend-design skill SKILL.md for high-design-quality implementation.`;
    }

    // Mermaid Terminal
    case "create-diagram": {
      const type = input.type || "flowchart";
      return `## Mermaid Diagram Creation

**Type**: ${type}

Supported:
- flowchart (TD, LR, etc.)
- sequence (interactions)
- state machine
- class diagram
- ER diagram
- Gantt chart
- pie chart
- git graph

**CLI**:
\`mermaid create --type ${type} --name my-diagram\`

Use the mermaid-terminal skill SKILL.md for syntax and examples.`;
    }

    // Project Status Tool
    case "view-status": {
      return `## Project Status View

**Command**:
\`status view [--format json|markdown|html]\`

**Output**:
- Current version
- Project status (stable, beta, alpha)
- Active branches
- Test coverage
- Code quality score
- Security score
- Milestone progress
- Next release ETA

Use the project-status-tool skill SKILL.md for full details.`;
    }

    // UX Journey Mapper
    case "create-journey-map": {
      const persona = input.persona || "First-time User";
      return `## UX Journey Map

**Persona**: ${persona}
**Stages**: awareness | consideration | decision | retention | advocacy

**Structure**:
- Touchpoints (name, channel, emotion, system)
- Pain points (friction areas)
- Opportunities (improvement moments)
- Emotional arc tracking

**Export formats**:
- Mermaid swimlane diagram
- JSON structured data
- HTML interactive view
- Markdown report

Use the ux-journey-mapper skill SKILL.md for complete guidance.`;
    }

    // Pre-Deploy Validator
    case "run-validation": {
      return `## Pre-Deployment Validation

**Checks** (all toggleable):
1. Code Quality (npm run lint)
2. Security (scan for hardcoded secrets)
3. Tests (npm test)
4. Dependencies (npm audit --audit-level=moderate)
5. Documentation (README.md, LICENSE.txt)

**Output**:
- Passed / Warnings / Failures / Errors
- Overall status: READY ✅ or BLOCKED ❌
- Exit code: 0 | 1 | 2 | 3

Use the pre-deploy-validator skill SKILL.md for complete implementation.`;
    }

    default:
      return `Tool '${toolName}' not yet fully implemented. Available skills: ${SKILLS.map((s) => s.name).join(", ")}`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// MCP REQUEST HANDLERS
// ═══════════════════════════════════════════════════════════════════════════

server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "list-skills",
        description: "List all available Fused Gaming skills",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "get-skill",
        description: "Get detailed documentation for a specific skill",
        inputSchema: {
          type: "object",
          properties: {
            skill: {
              type: "string",
              description:
                "Skill name (algorithmic-art, ascii-mockup, frontend-design, mermaid-terminal, project-status-tool, ux-journey-mapper, pre-deploy-validator)",
            },
          },
          required: ["skill"],
        },
      },
      {
        name: "get-skill-details",
        description: "Get metadata for a skill (name, description, tools, category)",
        inputSchema: {
          type: "object",
          properties: {
            skill: {
              type: "string",
              description: "Skill name",
            },
          },
          required: ["skill"],
        },
      },
      {
        name: "create-algorithmic-philosophy",
        description:
          "Generate an algorithmic philosophy for generative art",
        inputSchema: {
          type: "object",
          properties: {
            prompt: {
              type: "string",
              description: "What kind of algorithmic philosophy do you want?",
            },
          },
        },
      },
      {
        name: "generate-p5-sketch",
        description: "Generate p5.js sketch template based on philosophy",
        inputSchema: {
          type: "object",
          properties: {
            philosophy: {
              type: "string",
              description: "The algorithmic philosophy to implement",
            },
          },
        },
      },
      {
        name: "create-ascii-mockup",
        description: "Create responsive ASCII UI mockups across 5 breakpoints",
        inputSchema: {
          type: "object",
          properties: {
            screens: {
              type: "string",
              description: "What screens to design (mobile-first, desktop, etc.)",
            },
          },
        },
      },
      {
        name: "generate-tokens",
        description: "Generate design tokens (JSON + CSS)",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "design-component",
        description: "Design a frontend component with high aesthetic quality",
        inputSchema: {
          type: "object",
          properties: {
            component: {
              type: "string",
              description: "Component name (Button, Card, Form, etc.)",
            },
          },
        },
      },
      {
        name: "create-diagram",
        description:
          "Create a Mermaid diagram (flowchart, sequence, state, etc.)",
        inputSchema: {
          type: "object",
          properties: {
            type: {
              type: "string",
              description:
                "Diagram type (flowchart, sequence, state, class, er, gantt, pie, git)",
            },
          },
        },
      },
      {
        name: "view-status",
        description: "Get current project status view",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "create-journey-map",
        description: "Create a UX journey map for a user persona",
        inputSchema: {
          type: "object",
          properties: {
            persona: {
              type: "string",
              description: "User persona name",
            },
          },
        },
      },
      {
        name: "run-validation",
        description:
          "Run pre-deployment validation checks (quality, security, tests, deps, docs)",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
    ],
  };
});

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    const result = await handleToolCall(name, args as ToolInput);
    return {
      content: [
        {
          type: "text",
          text: result,
        } as TextContent,
      ],
    };
  } catch (error) {
    return {
      content: [
        {
          type: "text",
          text: `Error calling tool '${name}': ${error instanceof Error ? error.message : String(error)}`,
        } as TextContent,
      ],
      isError: true,
    };
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// START SERVER
// ═══════════════════════════════════════════════════════════════════════════

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("[fused-gaming-skills-mcp] Server running on stdio");
}

main().catch(console.error);
